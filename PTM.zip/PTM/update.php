<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		AddStduents
	</title>
	<style>
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:60%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		.dash input[type=text]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=date]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=submit]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
			border:none;
			background-color: #d2d2d2;
			color: #fff;
		}
		.dash button{
			padding: 10px;
			width: 30%;
			margin-top: 7px;
			margin-bottom: 10px;
			border:none;
			background-color: #d2d2d2;
			color: #fff;
		}
		.dash button:hover{
			background-color: black;
			transition: 0.5s ease;	
		}
		.dash select{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			 margin-bottom: 10px;
		}
		.dash label{
			color: #2d2d2d;
			
		}
		.dash input[type=submit]:hover{
			background-color: black;
			transition: 0.5s ease;
		}
	</style>
	<script src="yes.js"></script>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Update Existing Student Record:</h2></center><br>
	<div class="dash">
		<p>
			You Must Fill all information correctly
		</p><br>
		<p id="error">

		</p>
		<form action="update.php" method="POST">
			
		
		<h3>Select The Roll No. whose data you want to update:</h3>
		<?php

		$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
		$query=mysqli_query($connect,$select);
		$result=mysqli_fetch_assoc($query);
		
		
		
		$select_class="SELECT * from ".$result['ClassTeach']."";
				$fetch=mysqli_query($connect,$select_class);
				?>
		<select name="rollno" required= <?php  while($show=mysqli_fetch_assoc($fetch)):;?>>
			<option value=<?php echo $show['rollno']; ?>>
				<?php echo $show['rollno']; ?>
				</option><?php
				$_SESSION['ClassT']=$result['ClassTeach'];?>

			<?php endwhile; ?>
			
				 	

		</select><br>
		<button type="submit" name="submit">Submit</button>  <a href="t-dashboard.php">Cancel</a>
		</form>
		<?php

	if (isset($_POST['submit'])) {
		if (isset($_POST['rollno'])) {
			$rollno=$_POST['rollno'];
			$class=$_SESSION['ClassT'];
			
			$selectdata="SELECT * from " .$_SESSION['ClassT']. " where rollno='$rollno'";
			$rundata=mysqli_query($connect,$selectdata);
			$data=mysqli_fetch_array($rundata);?>
	
		<form action="update.php" method="post" onsubmit="return yes()" id="update">

		<label for="studentname"><strong>Student Name:</strong></label><br>
		<input type="text" name="name"  required="" id="name" value=<?php echo $data['name']; ?>><br>
		<label for="rollno"><strong>Student Roll No:</strong></label><br>
		<input type="text" name="rollno" required="" readonly="" id="rollno" value=<?php echo $data['rollno'];?>><br>
		<label for="class"><strong>Student Class:</strong></label><br>
		<input type="text" name="class" readonly=""   readonly="" value=<?php echo $data['class'];?>><br>
		<label for="gender"><strong>Student Gender:</strong></label><br>
		<select name="gender" required="">
			<option <?php echo $data['Gender'];?>>
				<?php echo $data['Gender'];?>
			</option>
			<option value="Male">
				Male
			</option>
			<option value="Female">
				Female
			</option>
		</select><br>
		<label for="fathername"><strong>Student Father Name:</strong></label><br>
		<input type="text" name="fathername" required="" id="fathername" value=<?php echo $data['fathername'];?> ><br>
		<label for="mobile"><strong>Student Mobile Number:</strong></label><br>
		<input type="text" name="mobile" required="" id="mobile" value=<?php echo $data['mobile'];?>><br>
		<label for="dateofbirth"><strong>Student Date of Birth:</strong></label><br>
		<input type="text" name="dob"  required="" value= <?php echo $data['dob'];?>><br>
		<label for="address"><strong>Student Address:</strong></label><br>
		<input type="text" name="address" required="" value=<?php echo $data['address'];?>><br>
		<input type="submit" name="update" value="Save Changes">
		
	</form>
	<?php
}
}
	?>

	<?php
	if (isset($_POST['update'])) {
		
					$name=mysqli_real_escape_string($connect, $_POST['name']);
					$rollno=mysqli_real_escape_string($connect,$_POST['rollno']);
					$gender=mysqli_real_escape_string($connect,$_POST['gender']);
					$fathername=mysqli_real_escape_string($connect,$_POST['fathername']);
					$mobile=mysqli_real_escape_string($connect,$_POST['mobile']);
					$dob=mysqli_real_escape_string($connect,$_POST['dob']);
					$address=mysqli_real_escape_string($connect,$_POST['address']);

					$update="UPDATE ".$_SESSION['ClassT']." SET name='$name',Gender='$gender', fathername='$fathername', dob='$dob',mobile='$mobile',
					address='$address' where rollno='$rollno'";
					$runupdate=mysqli_query($connect,$update);
					if ($runupdate) {
						?>
						<script type="text/javascript">
							alert("Update Sucessfull")
						</script>
						<?php
					}
					else{
						?>
						<script type="text/javascript">
							alert("An error occured while adding record!")
						</script>
						<?php
					}
				}
					?>
	</div><center>
		<a href="t-dashboard.php">Back to Dashboard</a>
	</center>
	<br><br>
	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

</body>
</html>
