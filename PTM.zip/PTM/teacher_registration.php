<?php
include("server2.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>Teacher Registration</title>
	
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "open sans";
		}
		.form{
			margin: 40px auto;
			width: 45%;
			padding: 10px;
			
			
		}
		input[type=text]{
			padding: 10px;
			width: 95%;
			margin: 8px 0px;
		}
		input[type=Password]{
			padding: 10px;
			width: 95%;
			margin: 8px 0px;
		}
		input[type=date]{
			padding: 10px;
			width: 95%;
			margin: 8px 0px;
		}
		select{
			padding: 10px;
			width: 100%;
			margin: 8px 0px;
		}
		table{
			border:2px solid black;
			margin: 8px 0px;
			background-color:#d2d2d2;

		}
		table th{
			padding: 10px;
			
			
		}
		input[type=submit]{
			width: 100%;
			padding: 10px;
			border: none;
			background-color: black;
			color: #fff;
		}
		input[type=submit]:hover{
			font-weight: bold;
			transition: 0.6s ease;
		}
	</style>
	<script src="verify.js"></script>
</head>
<body>
	<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center><br>
	<center><h2 style="background-color: black;color: white; padding: 10px; width: 50%;">Teacher Registration Form</h2></center><br>
	<div class="form">
	<form action="teacher_registration.php" method="POST" onsubmit="return radio()">
		<center><p id="error" style="background-color: #fddbf5; color: red; padding: 10px;">All fields are required</p></center>
		<label for="name">Name of Teacher:</label><br>
		<input type="text" name="teacher_name" placeholder="Enter your full name here" id="name" required=""><br>
		<label for="name">Choose Gender:</label><br>
		<select name="gender" required="">
			<option disabled="" selected="">Select Gender</option>
			<option value="Male">Male</option>
			<option value="Fe-male">Female</option>
		</select>
		<label for="Password">Password:</label><br>
		<input type="Password" name="Password" placeholder="Create Password atleast 6 characters" id="Password" required=""><br>
		<label for="Mobile Number">Mobile Number:</label><br>
		<input type="text" name="Mobile" placeholder="Enter Mobile Number of 10 digits" id="Mobile" required=""><br>
		<label for="name">Full Address:</label><br>
		<input type="text" name="Address" placeholder="Enter your full Address here" id="Address" required=""><br>
		<label for="Qualification">Qualification:</label><br>
		<select name="qualification" id="qualification" required="">
			<option selected="" disabled="">Choose Qualification</option>
			<option value="MCA">MCA</option>
			<option value="MBA"> MBA</option>
			<option value="B.Ed"> B.Ed</option>
			<option value="B.TECH"> B.TECH</option>
			<option value="M.TECH">M.TECH</option>
			<option>Others</option>
		</select>
		<label for="Class">Select Classes You Will Teach:</label><br>

		<select name="class" required="">
			<option selected="" disabled="">Select Class you will teach</option>
			<option value="10th">10th (HTML, CSS)</option>
			<option value="11th">11th (My SQL, PHP)</option>
			<option value="12th" >12th (Software Engineering, JAVA)</option>
		</select>
		
		<label>Date Of Joining:</label><br>
		<input type="date" name="joining" required=""><br>
		
		 <input type="submit" name="RegisterTeacher" value="Confirm Registration"> <br><br>
		<label>Already Have Account<a href="dashboard.php">Log In</a></label>
	</form>

	</div>
	<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center>
	
		

	
</body>
</html>

<?php?>