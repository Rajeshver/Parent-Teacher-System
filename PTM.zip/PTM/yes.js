

 function yes() {
	

var name=document.getElementById('name').value;
var rollno=document.getElementById('rollno').value;
var fathername=document.getElementById('fathername').value;
var mobile=document.getElementById('mobile').value;
var address=document.getElementById('address').value;
if (name=="") {
	document.getElementById('error').innerHTML="Name Cannot be empty";
	return false;
}
else if (!IsNaN(name)) {
	document.getElementById('error').innerHTML="Name Cannot contain numbers";
	return false;

}
else if (fathername=="") {
	document.getElementById('error').innerHTML="Father Name Cannot be empty";
	return false;

}
else if (!IsNaN(fathername)) {
	document.getElementById('error').innerHTML="Father Name Cannot contain numbers";
	return false;

}
else if (mobile=="") {
	document.getElementById('error').innerHTML="Mobile Number Cannot be empty";
	return false;

}
else if (IsNaN(mobile)) {
	document.getElementById('error').innerHTML=" Mobile must contain numbers only";
	return false;

}
else if (address=="") {
	document.getElementById('error').innerHTML="Address Cannot be empty";
	return false;

}
else{
	return true;
}
}
