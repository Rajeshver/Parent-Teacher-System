<?php

include("server2.php");


?>
<!DOCTYPE html>
<html>
<head>
	<title>parent registration</title>
</head>


	
	<style type="text/css">
		*{
			padding: 0;
			margin:0;
		}
		.form{
			height: auto;
			width:50%;
			margin: auto;
			border:2px solid black;
			
			box-shadow: 4px 3px 15px #2d2d2d; 
			
			padding: 20px;
		}
		.form input[type=text]{
			width: 85%;
			padding: 10px;
			background-color: #d2d2d2;
			border-radius: 5px;
		}
		.form input[type=password]{
			width: 85%;
			padding: 10px;
			background-color: #d2d2d2;
			border-radius: 5px;
		}
		.form select{
			width: 88%;
			padding: 10px;
			background-color: #d2d2d2;
			border-radius: 5px;
		}
		.form input[type=submit]{
			width: 50%;
			padding: 10px;
			border: none;
			background-color: black;
			color: #fff;
			border-radius: 5px;
		}
	</style>
</head>
<body>
	<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center><br>
	<center><h2 style="background-color: black;color: white; padding: 10px; width: 40%;">Parent Registration Form</h2></center><br>
	
	<?php if (isset($_SESSION['msg'])) {
		
		echo "<center><h3>",$_SESSION['msg'],"</h3></center>";
		unset($_SESSION['msg']);
	} ?>
	<div class="form">
		<form method="POST" action="registration.php">
		<center><h3>First Verify Student's Details</h3></center>
		Enter The Students Name:<br>
		<input type="text" name="name"><br><br>
		
		Enter The Students Roll No.:<br>
		<input type="text" name="rollno"><br><br>
		Select The Students Class:<br>
		<select name="class" >
			<option selected="" disabled="">Select Class</option>
			<option  name="10th">
				10th
			</option>
			<option  name="11th">
				11th
			</option>
			<option name="12th">
				12th
			</option>
		</select><br><br>
		Enter Your Name:<br>
		<input type="text" name="uname"><br><br>
		
		Enter Password:<br>
		<input type="password" name="password"><br><br>
		Enter Mobile Number:<br>
		<input type="text" name="mobile"><br><br>
		Relation With Student:
		<select name="Relation"><option disabled="">Select Relation</option><option value="Father">Father</option><option value="Mother">Mother</option></select><br><br>
		<input type="submit" name="fetch" value="Verify Details">
		
		
		

		</form>
		<a href="logout.php">Back to Dashboard</a>





	</div><br><br>
	<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center>
	

</body>
</html>