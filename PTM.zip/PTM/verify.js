


function radio(){
	
	var name=document.getElementById('name').value;
	var pass=document.getElementById('Password').value;
	var mobile=document.getElementById('Mobile').value;
	var Address=document.getElementById('Address').value;
	var classes=document.getElementById('class').value;
	
	
	if (name=="") {
		document.getElementById('error').innerHTML="Name cannot be empty";

		
		return false;
	}
	else if(pass==""){
		document.getElementById('error').innerHTML="Password cannot be empty";

		return false;
	}
	else if(pass.length<6){
		document.getElementById('error').innerHTML="Password must be of 6 characters";

		return false;
	}

	else if(mobile==""){
		document.getElementById('error').innerHTML="Mobile number cannot be empty";

		return false;
	}
	else if(isNaN(mobile)){
		document.getElementById('error').innerHTML="Mobile number cannot comtain characters";

		return false;
	}
	else if(mobile.length!=10){
		document.getElementById('error').innerHTML="Mobile number must be of 10 digits";

		return false;
	}
	else if(Address==""){
		document.getElementById('error').innerHTML="Address cannot be empty";

		return false;
	}
	
	
		else{
			return true;
		}
}
/*
		
	}*/
