<?php
include ("server2.php");


if (!isset($_SESSION['mobile'])) {
	header('location:dashboard.php');
	unset($_SESSION['mobile']);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>P-dashboard</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		.dash{
			height: auto;
			width:60%;
			margin: auto;
			border:2px solid black; 
			background-color: #d2d2d2;
			border-radius: 10px;
			padding: 20px;
			
		}
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		a{
			text-decoration: none;
			color: white;
		}
		

	</style>
</head>
<body>
	
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Parent Dashboard</h2></center><br>
	<div class="dash"><center>
		<?php if (isset($_SESSION['mobile'])) {
		echo "<h4>Welcome Parent</h4>" ;
	}
	?>
	<?php if (isset($_SESSION['msg'])) {
		
		echo "<center><h3>",$_SESSION['msg'],"</h3></center>";
		unset($_SESSION['msg']);
	} ?>
		<button><a href="child_data.php"> <h3>Student Data</h3></a></button><br><br>

		<button><a href="child_attendance.php"><h3>Student Attendance</h3></a></button><br><br>
		<button><h3>Teacher's Info</h3></button><br><br>
		<button><a href="p_account.php"><h3>My Data</h3></a></button><br><br></center><br>
		
			
				<center><th><a href="logout.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px;">Log Out</a></th></center><br>

				
			

		
	</div><br><br><br><br>

	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

</body>
</html>