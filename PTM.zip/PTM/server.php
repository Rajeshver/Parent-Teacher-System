<?php
session_start();
$host='localhost';
		$username='root';
		$password1='';
		$database='ptm';

	$connect=mysqli_connect($host,$username,$password1,$database);
	if (!$connect) {
	echo "cannot connect";
}
else
{
	echo "connected";
}

	if (isset($_POST['fetch'])) {
		

		$sname=$_POST['name'];
		
		$rollno=$_POST['rollno'];
		$class=$_POST['Class'];
		
		$name=$_POST['uname'];
	$password=$_POST['password'];
	$mobile=$_POST['mobile'];
	$relation=$_POST['Relation'];

	
		switch ($class) {
			case '10th':
			$user_check="SELECT * FROM parent WHERE mobile='$mobile' AND rollno='$rollno' LIMIT 1";
	$exist=mysqli_query($connect,$user_check);
	$users=	mysqli_fetch_assoc($exist);
	if ($users) {
	if ($users['mobile']==$mobile AND $users['rollno']==$rollno){
		$_SESSION['message']="Mobile number already exist,Please log in or choose different mobile number";
				header("location:dashboard.php");

		}
	}
			
			
			$select="SELECT * from 10th where name='$name' AND rollno='$rollno'";
		
		$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {
				$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
		$query2=mysqli_query($connect,$insert);
		
			
			$_SESSION['mobile']=$mobile;
			$_SESSION['msg']="You are Successfully Logged In";
			header('location:p-dashboard.php');
		}
		else{
			$_SESSION['msg']="No record found.Please enter correct information";
			header('location:registration.php');
		}
	
	
				break;
			
			case '11th':
			$user_check="SELECT * FROM parent WHERE mobile='$mobile' AND rollno='$rollno' LIMIT 1";
			$exist=mysqli_query($connect,$user_check);
			$users=	mysqli_fetch_assoc($exist);
			if ($users) {
			if ($users['mobile']==$mobile AND $users['rollno']==$rollno){
			$_SESSION['message']="Mobile number already exist,Please log in or choose different mobile number";
				header("location:dashboard.php");

		}
	}
	

			$select="SELECT * from 11th where name='$name' AND rollno='$rollno'";
			$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {

				$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
		$query2=mysqli_query($connect,$insert);
		
			
			$_SESSION['mobile']=$mobile;
			$_SESSION['msg']="You are Successfully Logged In";
			header('location:p-dashboard.php');
		}
		else{
			$_SESSION['msg']="No record found.Please enter correct information";
			header('location:registration.php');
		
	}
				break;
				
			case '12th':
			$user_check="SELECT * FROM parent WHERE mobile='$mobile' AND rollno='$rollno' LIMIT 1";
			$exist=mysqli_query($connect,$user_check);
			$users=	mysqli_fetch_assoc($exist);
			if ($users) {
			if ($users['mobile']==$mobile AND $users['rollno']==$rollno){
		$_SESSION['message']="Mobile number already exist,Please log in or choose different mobile number";
				header("location:dashboard.php");

		}
	}
	
			$select="SELECT * from 12th where name='$name' AND rollno='$rollno'";
			$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {

			$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
		$query2=mysqli_query($connect,$insert);
		
			
			$_SESSION['mobile']=$mobile;
			$_SESSION['msg']="You are Successfully Logged In";
			header('location:p-dashboard.php');
		}
		else{
			?>
			<script type="text/javascript">
				alert("No record found.Please enter correct information");
				header('location:registration.php');

			</script>
			<?php
			
			
		
	}
					
					break;
					default:
				?>
				<script type="text/javascript">
					alert("no record available");
					
				</script>
				<?php
				break;
		}
		
		
			
		





}









?>