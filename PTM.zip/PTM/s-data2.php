<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>P-Data</title>
	<style type="text/css">
	*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		.data{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
		}
		.data input{
			width: 85%;
			padding: 10px;
			margin-top: 10px;
		}
		.data select{
			width: 90%;
			padding: 10px;
		}
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		table th,td{
			align-content: center;
			align-items: center;
			justify-content: center;
			text-align: center;
			border: none;
			border-bottom: 2px solid black;
			padding: 10px;
		}
		table{
			margin-bottom: 60px;
		}
		a{
			color: black;
		}
		footer{
			margin-top:100px; 
		}
		td:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}
		th:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}

	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Student Database</h2></center><br>
	<div class="data">
		<center>
		<?php
			if (isset($_SESSION['msg'])) {
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
			</center>
		<form action="s-data2.php" method="post">
	
		<label>Enter Roll No:</center><br>
		<input type="text" name="RollNo" required=""><br><br>
		<label>Select Class:</label><br><br>

<select name="Class" required="">
				<option disabled selected>Select Class</option><option value="10th" name="10th">10th</option>
				
				<option value="11th" name="11th">11th</option>
				<option value="12th" name="12th">12th</option>
				

			</select><br><br>
			<button type="submit" name="fetch_student">Fetch Results</button><br><br>
			<center><th><a href="t-dashboard.php">Back to Teacher Dashboard</a></th></center>
			</form></div><br>


			<?php
			if (isset($_POST['fetch_student'])) {
				if (isset($_POST['Class'])) {
					# code...
				
				
				$class=$_POST['Class'];
				$rollno=$_POST['RollNo'];
				switch ($class) {
					case '10th':
						$Select="SELECT * from 10th where rollno='$rollno' AND class='$class'";
						$query=mysqli_query($connect,$Select);
						while ($res=mysqli_fetch_assoc($query)) {
				
				?>
				<br>
				<center>
				<table  cellpadding="10" width="60%"  >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><td>Name:</td><th><?php echo $res['name'],"";?></th></tr>
					<tr><td>Class:</td><th><?php echo $res['class'],"";?></th></tr>
					<tr><td>Roll No.:</td><th><?php echo $res['rollno'],"";?></th></tr>
					<tr><td>Gender:</td><th><?php echo $res['Gender'],"";?></th></tr>
					<tr><td>Father Name:</td><th><?php echo $res['fathername'],"";?></th></tr>
					<tr><td>Mobile Number:</td><th><?php echo $res['mobile'],"";?></th></tr>
					<tr><td>D.O.B:</td><th><?php echo $res['dob'],"";?></th></tr>
					<tr><td>Address:</td><th><?php echo $res['address'],"";?></th></tr>
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">



					 &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white">Back To Dashboard</a> </th></tr>
				</table>
				<?php

			}	
			
				$select="SELECT * from parent where sclass='$class' AND srollno='$rollno'";
				$query2=mysqli_query($connect,$select);
				while ($rest=mysqli_fetch_assoc($query2)) {
				?>
				<center>
				<table  cellpadding="10" width="60%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Parent Details</th></tr>
					<tr><td>Name:</td><th><?php echo $rest['name'],"";?></th></tr>
					<tr><td>Mobile:</td><th><?php echo $rest['mobile'],"";?></th></tr>
					<tr><td>Relation:</td><th><?php echo $rest['relation'],"";?></th></tr>
					<tr><td>Student Name:</td><th><?php echo $rest['sname'],"";?></th></tr>
					<tr><td>Student Class:</td><th><?php echo $rest['sclass'],"";?></th></tr>
					<tr><td>Student RollNo:</td><th><?php echo $rest['srollno'],"";?></th></tr>
				
				<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">



					 &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white">Back To Dashboard</a> </th></tr>
					</center>
				</table>
						
				



					<?php
				}
						break;
						case '11th':
						$Select="SELECT * from 11th where rollno='$rollno' AND class='$class'";
						$query=mysqli_query($connect,$Select);
						while ($res=mysqli_fetch_assoc($query)) {
				
				?>
				<br>
				<center>
				<table  cellpadding="10" width="50%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><td>Name:</td><th><?php echo $res['name'],"";?></th></tr>
					<tr><td>Class:</td><th><?php echo $res['class'],"";?></th></tr>
					<tr><td>Roll No.:</td><th><?php echo $res['rollno'],"";?></th></tr>
					<tr><td>Gender:</td><th><?php echo $res['Gender'],"";?></th></tr>
					<tr><td>Father Name:</td><th><?php echo $res['fathername'],"";?></th></tr>
					<tr><td>Mobile Number:</td><th><?php echo $res['mobile'],"";?></th></tr>
					<tr><td>D.O.B:</td><th><?php echo $res['dob'],"";?></th></tr>
					<tr><td>Address:</td><th><?php echo $res['address'],"";?></th></tr>
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;"> &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white" >Back To Dashboard</a> </th></tr>
				</table></center>
				<?php	
			}


					$select="SELECT * from parent where sclass='$class' AND srollno='$rollno'";
				$query2=mysqli_query($connect,$select);
				while ($rest=mysqli_fetch_assoc($query2)) {
				?>
				<center>
				<table  cellpadding="10" width="50%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Parent Details</th></tr>
					<tr><td>Name:</td><th><?php echo $rest['name'],"";?></th></tr>
					<tr><td>Mobile:</td><th><?php echo $rest['mobile'],"";?></th></tr>
					<tr><td>Relation:</td><th><?php echo $rest['relation'],"";?></th></tr>
					<tr><td>Student Name:</td><th><?php echo $rest['sname'],"";?></th></tr>
					<tr><td>Student Class:</td><th><?php echo $rest['sclass'],"";?></th></tr>
					<tr><td>Student RollNo:</td><th><?php echo $rest['srollno'],"";?></th></tr>
				
				<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">



					 &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white" >Back To Dashboard</a> </th></tr>
					</center>
				</table>
						
				



					<?php
				}

			break;
			case '12th':
			
			
						$Select="SELECT * from 12th where rollno='$rollno' AND class='$class'";
						$query=mysqli_query($connect,$Select);
						while ($res=mysqli_fetch_assoc($query)) {
				
				?>
				<br>
				<center>
				<table  cellpadding="10" width="50%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><td>Name:</td><th><?php echo $res['name'],"";?></th></tr>
					<tr><td>Class:</td><th><?php echo $res['class'],"";?></th></tr>
					<tr><td>Roll No.:</td><th><?php echo $res['rollno'],"";?></th></tr>
					<tr><td>Gender:</td><th><?php echo $res['Gender'],"";?></th></tr>
					<tr><td>Father Name:</td><th><?php echo $res['fathername'],"";?></th></tr>
					<tr><td>Mobile Number:</td><th><?php echo $res['mobile'],"";?></th></tr>
					<tr><td>D.O.B:</td><th><?php echo $res['dob'],"";?></th></tr>
					<tr><td>Address:</td><th><?php echo $res['address'],"";?></th></tr>
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">
						 &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white">Back To Dashboard</a> </th></tr>
				</table></center>
				

				<?php
			}	
			
				$select="SELECT * from parent where sclass='$class' AND srollno='$rollno'";
				$query2=mysqli_query($connect,$select);
				while ($rest=mysqli_fetch_assoc($query2)) {
				?>
				<center>
				<table  cellpadding="10" width="50%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Parent Details</th></tr>
					<tr><td>Name:</td><th><?php echo $rest['name'],"";?></th></tr>
					<tr><td>Mobile:</td><th><?php echo $rest['mobile'],"";?></th></tr>
					<tr><td>Relation:</td><th><?php echo $rest['relation'],"";?></th></tr>
					<tr><td>Student Name:</td><th><?php echo $rest['sname'],"";?></th></tr>
					<tr><td>Student Class:</td><th><?php echo $rest['sclass'],"";?></th></tr>
					<tr><td>Student RollNo:</td><th><?php echo $rest['srollno'],"";?></th></tr>
				
				<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">



					 &nbsp;&nbsp;&nbsp;<a href="t-dashboard.php" style="color: white">Back To Dashboard</a> </th></tr>
					</center>
				</table>
						
				



					<?php
				}		
				
	
		
			
			break;
					
					default:
						?>
					
						<script type="text/javascript">
							alert('Sorry!Wrong Input or No Data Available');
						</script>
						<?php
		
						break;
				}
			}
			else{
					$_SESSION['msg']="Sorry! No record found for given rollno. Please try different one";	
			}
			}
			?>
			
			
				
				
			
				
			







			


			<br><br>
			<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
</body>
</html>