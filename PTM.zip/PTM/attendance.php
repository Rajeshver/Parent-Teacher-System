<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>AttendanceChoose</title>
	<style type="text/css">
				*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		h3{
			padding: 5px 8px;
		}
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Attendace</h2></center><br>
	<div class="dash"><center>
		<button><a href="view_attendance.php"><h3> View Attendance</h3></a></button><br><br>
		<button><a href="attendance_info.php"><h3>Take Attendance</h3></a> </button><br><br>
		<center><th><a href="t-dashboard.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px;">Back To Dashboard</a></th></center><br>
		</center>
	</div>

</body>
</html>