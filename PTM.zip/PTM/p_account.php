<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>My Data</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
	
		
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		table th,td{
			align-content: center;
			align-items: center;
			justify-content: center;
			text-align: center;
			border: none;
			border-bottom: 2px solid black;
			padding: 15px;
		}
		table{
			margin-bottom: 60px;
		}
		a{
			color: black;
		}
		td:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}
		th:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}



		
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Parent Account</h2></center><br>
	<?php
	
			
			$select="SELECT * from parent where mobile=".$_SESSION['mobile']."";
			$query=mysqli_query($connect,$select);
			while ($res=mysqli_fetch_assoc($query)) {
				echo "<h3><center>Welcome ",$res['name'],"</h3></center>";
				?><br>
				<center>
				<table  cellpadding="10" width="60%" >
					<tr><th colspan="2" style="background-color: #2d2d2d; color: white;">Parent Details</th></tr>
					<tr><td>Name:</td><th><?php echo $res['name'],"";?></th></tr>
					<tr><td>Mobile:</td><th><?php echo $res['mobile'],"";?></th></tr>
					<tr><td>Relation:</td><th><?php echo $res['relation'],"";?></th></tr>
					<tr><td>Student Name:</td><th><?php echo $res['sname'],"";?></th></tr>
					<tr><td>Student Class:</td><th><?php echo $res['sclass'],"";?></th></tr>
					<tr><td>Student RollNo:</td><th><?php echo $res['srollno'],"";?></th></tr>
					<tr><th colspan="2" style="background-color: #d2d2d2; color: black;"><a href="#">Update Account</a>&nbsp;&nbsp;&nbsp;<a href="logout.php"> Log Out</a>&nbsp;&nbsp;&nbsp;<a href="p-dashboard.php">Back To Dashboard</a> </th></tr>
				</table></center>
				<?php	
			}

			?>
				<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

</body>
</html>