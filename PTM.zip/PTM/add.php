<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		AddStduents
	</title>
	<style>
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:60%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		.dash input[type=text]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=date]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=submit]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
			border:none;
			background-color: #d2d2d2;
			color: #fff;
		}
		.dash select{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			 margin-bottom: 10px;
		}
		.dash label{
			color: #2d2d2d;
			
		}
		.dash input[type=submit]:hover{
			background-color: black;
			transition: 0.5s ease;
		}
	</style>
	<script src="yes.js"></script>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Add New Student's Data:</h2></center><br>
	<div class="dash">
		<p>
			You Must Fill all information correctly
		</p><br>
		<p id="error">
			
		</p>
		<form action="add.php" method="post" onsubmit="return yes()" id="add">

		<label for="studentname"><strong>Student Name:</strong></label><br>
		<input type="text" name="name" placeholder="Enter the students name" required="" id="name"><br>
		<label for="rollno"><strong>Student Roll No:</strong></label><br>
		<input type="text" name="rollno" placeholder="Enter the students rollno" required="" id="rollno"><br>
		<label for="class"><strong>Student Class:</strong></label><br>
		<input type="text" name="class" placeholder="Enter the students class"  readonly="" value=<?php

		$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
		$query=mysqli_query($connect,$select);
		$result=mysqli_fetch_assoc($query);
		echo $result['ClassTeach'];
		?>><br>
		<label for="gender"><strong>Student Gender:</strong></label><br>
		<select name="gender" required="">
			<option value="Male">
				Male
			</option>
			<option value="Female">
				Female
			</option>
		</select><br>
		<label for="fathername"><strong>Student Father Name:</strong></label><br>
		<input type="text" name="fathername" placeholder="Enter the students father name" required="" id="fathername"><br>
		<label for="mobile"><strong>Student Mobile Number:</strong></label><br>
		<input type="text" name="mobile" placeholder="Enter the students Mobile Number" required="" id="mobile"><br>
		<label for="dateofbirth"><strong>Student Date of Birth:</strong></label><br>
		<input type="date" name="dob" placeholder="Enter the students Date of Birth" required=""><br>
		<label for="address"><strong>Student Address:</strong></label><br>
		<input type="text" name="address" placeholder="Enter the students Address" required="" id="address"><br>
		<input type="submit" name="add" value="Add Student">
	</form>

	</div><center>
		<a href="t-dashboard.php">Back to Dashboard</a>
	</center>
	<br><br>
	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

	<?php
	if (isset($_POST['add'])) {
		if (isset($_POST['gender'])) {
			$name=mysqli_real_escape_string($connect, $_POST['name']);
			$class=mysqli_real_escape_string($connect,$_POST['class']);
			$rollno=mysqli_real_escape_string($connect,$_POST['rollno']);
			$gender=mysqli_real_escape_string($connect,$_POST['gender']);
			$fathername=mysqli_real_escape_string($connect,$_POST['fathername']);
			$mobile=mysqli_real_escape_string($connect,$_POST['mobile']);
			$dob=mysqli_real_escape_string($connect,$_POST['dob']);
			$address=mysqli_real_escape_string($connect,$_POST['address']);

			switch ($class) {
				case '10th':
					$check="SELECT  * from 10th where rollno='$rollno'";
					$run=mysqli_query($connect,$check);
					if ($yes=mysqli_num_rows($run)>0) {
						?>
						<script type="text/javascript">
							alert("Student with same rollno already exist");
						</script>
						<?php
					}
					else{
						$insert="INSERT into 10th(name,class,rollno,Gender,fathername,mobile,dob,address)VALUES('$name',
						'$class','$rollno','$gender','$fathername','$mobile','$dob','$address')";
						$add=mysqli_query($connect,$insert);
						if ($add) {
							?>
						<script type="text/javascript">
							alert("One Record Added Successfully")
						</script>
						<?php
						}
						else{
							?>
							<script type="text/javascript">
								alert("An error occured while adding record!")
							</script>
							<?php
						}
						
					}
					break;
					case '11th':
					$check="SELECT * from 11th where rollno='$rollno'";
					$run=mysqli_query($connect,$check);
					if ($yes=mysqli_num_rows($run)>0) {
						?>
						<script type="text/javascript">
							alert("Student with same rollno already exist");
						</script>
						<?php
					}
					else{
						$insert="INSERT into 11th(name,class,rollno,Gender,fathername,mobile,dob,address)VALUES('$name',
						'$class','$rollno','$gender','$fathername','$mobile','$dob','$address')";
						$add=mysqli_query($connect,$insert);
						if ($add) {
							?>
						<script type="text/javascript">
							alert("One Record Added Successfully")
						</script>
						<?php
						}
						else{
							?>
							<script type="text/javascript">
								alert("An error occured while adding record!")
							</script>
							<?php
						}
						
					}
					break;
					case '12th':
					$check="SELECT * from 12th where rollno='$rollno'";
					$run=mysqli_query($connect,$check);
					if ($yes=mysqli_num_rows($run)>0) {
						?>
						<script type="text/javascript">
							alert("Student with same rollno already exist");
						</script>
						<?php
					}
					else{
						$insert="INSERT into 12th(name,class,rollno,Gender,fathername,mobile,dob,address)VALUES('$name',
						'$class','$rollno','$gender','$fathername','$mobile','$dob','$address')";
						$add=mysqli_query($connect,$insert);
						if ($add) {
							?>
						<script type="text/javascript">
							alert("One Record Added Successfully")
						</script>
						<?php
						}
						else{
							?>
							<script type="text/javascript">
								alert("An error occured while adding record!")
							</script>
							<?php
						}
						
					}
					break;

				
				default:
					
					break;
			}
			
		}
		else{
			?>
			<script type="text/javascript">
				alert("You must select your gender")
			</script>

			<?php
		}
	}
	else{

		
	}

	?>


</body>
</html>