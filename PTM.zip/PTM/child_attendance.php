<?php
include ("server2.php");


if (!isset($_SESSION['mobile'])) {
	header('location:dashboard.php');
	unset($_SESSION['mobile']);
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>
		Child_Attendance
	</title>
	<style>
	*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		table th,td{
			align-content: center;
			align-items: center;
			justify-content: center;
			text-align: center;
			border: none;
			border-bottom: 2px solid black;
			padding: 15px;
		}
		table{
			margin-bottom: 60px;
		}
		a{
			color: black;
		}
		td:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}
		th:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}

	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Students Attendance Record</h2></center><br>
	<center>
	<table width="65%">
		
	
	<?php
	$select1="SELECT * from parent where mobile=".$_SESSION['mobile']."";
	$select=mysqli_query($connect,$select1);
	$res=mysqli_fetch_assoc($select);
	$rollno=$res['srollno'];
	?>
	<tr>
			<th colspan="2" style="background-color: #2d2d2d; color: white">
				Student Details:
			</th>
		</tr>
	<tr>
		<th>
			Name:
		</th>
		<th>
			<?php echo $res['sname'];?>
		</th>
	</tr>
	<tr>
		<th>
			Roll Number:
		</th>
	
	
		<th>
			<?php echo $res['srollno'];?>
		</th>
	</tr>
	<tr>
			<th colspan="2" style="background-color: #2d2d2d; color: white">
				Attendance Details:
			</th>
		</tr>
		<tr>
			<th>
				Date:
			</th>
			<th>
				Result:
			</th>
		</tr>
	<?php
	$rollno2=intval($rollno);
	if ($res['sclass']=="10th") {
		$html=mysqli_query($connect,"SELECT * from html_10th ORDER BY DateOfAttendance");
		$css=mysqli_query($connect,"SELECT * from css_10th ORDER BY DateOfAttendance");
		?>
			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					HTML Attendance:
				</th>
			</tr>
			<?php
		while($res1=mysqli_fetch_assoc($html)){
			
			$Present=array($res1['Present_RollNo']);
			$Absent=array($res1['Absent_RollNo']);
			
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res1['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res1['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res1['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
	?>

			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					CSS Attendance:
				</th>
			</tr>
			<?php
		while($res2=mysqli_fetch_assoc($css)){
			
			$Present=array($res2['Present_RollNo']);
			$Absent=array($res2['Absent_RollNo']);
			
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res2['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res2['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res2['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
	?>
	<?php
			
	}
	elseif($res['sclass']=="11th"){
		$mysql=mysqli_query($connect,"SELECT * from mysql_11th ORDER BY DateOfAttendance");
		$php=mysqli_query($connect,"SELECT * from php_11th ORDER BY DateOfAttendance");
		
		?>
			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					MySQL Attendance:
				</th>
			</tr>
			<?php
		while($res3=mysqli_fetch_assoc($mysql)){
			
			$Present=array($res3['Present_RollNo']);
			$Absent=array($res3['Absent_RollNo']);
			
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res3['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res3['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res3['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
	?>
			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					PHP Attendance:
				</th>
			</tr>
			<?php
		while($res4=mysqli_fetch_assoc($php)){
			
			$Present=array($res4['Present_RollNo']);
			$Absent=array($res4['Absent_RollNo']);
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res4['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res4['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res4['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
		
		
	}
	else{
		$java=mysqli_query($connect,"SELECT * from java_12th ORDER BY DateOfAttendance	");
		$software=mysqli_query($connect,"SELECT * from softwareengineering_12th ORDER BY DateOfAttendance");
		?>
			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					Java Attendance:
				</th>
			</tr>
			<?php
		while($res5=mysqli_fetch_assoc($java)){
			
			$Present=array($res5['Present_RollNo']);
			$Absent=array($res5['Absent_RollNo']);
			
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res5['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res5['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res5['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
	?>
			<tr>
				<th colspan="2" style="background-color: #2d2d2d; color: white">
					Software Engineering Attendance:
				</th>
			</tr>
			<?php
		while($res6=mysqli_fetch_assoc($software)){
			
			$Present=array($res6['Present_RollNo']);
			$Absent=array($res6['Absent_RollNo']);
			

			if(in_array($rollno2, $Present)){?>
				<tr>
					<th>
						<?php echo $res6['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Present"; ?>
					</th>
				</tr>
				<?php
				
			}
			elseif(in_array($rollno2, $Absent)){?>

			<tr>
					<th>
						<?php echo $res6['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "Absent"; ?>
					</th>
				</tr>
			<?php
		}
		else{?>

			<tr>
					<th>
						<?php echo $res6['DateOfAttendance']; ?>
					</th>
					<th>
						<?php echo "On Leave"; ?>
					</th>
				</tr>
			<?php
		}
	}
		

		
		

		
		
	}
		
	
	?>
	<tr>
		<th colspan="2">
			<a href="p-dashboard.php" style="color: black">Back To Dashboard</a>
		</th>
	</tr>
</table>
</center><br><br>
<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
	
	

</body>
</html>