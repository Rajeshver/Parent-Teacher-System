<?php  	
		$presents = array();
		$absents = array();
		$Leaves = array();

		if (isset($_POST['calculate'])) {


			if (!isset($_POST['present_rolls'])) {
				?>
				<script type="text/javascript">
					alert("You Must Select Atleast One option!")
				</script>
				
				<?php
			}
			else{
				$P=$_POST['present_rolls'];
				$P2=implode(",", $P);
				array_push($presents, $P2);
			

			}
			if (!isset($_POST['absents_rolls'])) {
								?>
				<script type="text/javascript">
					alert("You Must Select Atleast One option!")
				</script>
				
				<?php
				
			}
			else{
				$A=$_POST['absents_rolls'];
				$A2=implode(",", $A);
				array_push($absents, $A2);

			}
			if (!isset($_POST['leaves_rolls'])) {
							?>
				<script type="text/javascript">
					alert("You Must Select Atleast One option!")
				</script>
				
				<?php
				
			}
			else{
				$L=$_POST['leaves_rolls'];
			$L2=implode(",", $L);
			array_push($Leaves, $L2);
			}
		

		
			
		
		
	}
	

	
			
			
		
			



		
				
	

?>