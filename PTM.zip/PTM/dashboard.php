<?php include "server2.php";?>


<!DOCTYPE html>
<html>
<head>
	<title>DashBoard</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
			text-decoration: none;

		}
		body{
			background-color: #d2d2d2;
		}
		input{
			width: 70%;
			padding: 10px;
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h3{
			color: white;
			background-color: black;
			padding: 10px;
			width: 70%;


		}
		table{
			margin: 50px auto;
		}
		
		
		button{
			padding: 8px;
			width: 20%;
			border:none;
			background-color: #2d2d2d;
			color: white;
		}
		button:hover{
			background-color: black;
			transition: 0.5s ease;
		}
		a{
			color: black;
			padding: 5px;
			border-bottom: 2px solid black;
		}
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br><br>
	<?php
	
	if (isset($_SESSION['msg'])) {

		echo "<center><h2>",$_SESSION['msg'],"</h2></center>";
		unset($_SESSION['msg']);
	}
	?>
	<table width="90%"  cellpadding="10" cellspacing="10"><tr><td><h3>Teacher Log In</h3></td><td><h3>Parent Log In</h3></td></tr>
		<tr><td>Teacher Mobile:</td><td>Parent Mobile:</td>
			<form method="POST" action="dashboard.php">
		<tr><td><input type="text" name="t_mobile" placeholder="Teacher Mobile"></td>
			<td><input type="text" name="p_mobile" placeholder="Parent Mobile"></td></tr>
			<tr><td>Password:</td><td>Password:</td>
		<tr><td><input type="password" name="tPassword" placeholder="Teacher Password"></td>
			<td><input type="password" name="ppassword" placeholder="Parent Password"></td></tr>
			<tr><td><button type="submit" name="teacher_login">Log In</button></td>
				<td><button type="submit" name="parent_login">Log In</button></td></tr>
				</form>
				<tr><td><a href="teacher_registration.php">Create New Account</a></td><td><a href="registration.php">Create New Account</a></td></tr></tr></tr></table><br><br><br><br>
					<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
					



</body>
</html>