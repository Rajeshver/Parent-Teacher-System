<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>View-Attendance</title>
	<style type="text/css">
				*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		h3{
			padding: 5px 8px;
		}
		input[type=submit]{
			width:90%;
			border: none;
			background-color: #d2d2d2;
			color: white;
			padding: 10px;
		}
		input[type=submit]:hover{
			background-color: black;
			color: white;
			transition: 0.5s ease;
		}
		a{
			text-decoration: none;
			color: white;
		}
		.dash select{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			 margin-bottom: 10px;
		}
		
		table th,td{
			border:2px solid black;	
			padding: 8px;
		}
		th{
			background-color: #d2d2d2;
			color:black;
		}
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>View Attendance</h2></center><br>
	<div class="dash">
		
			
		
		
		<p>Select Subject:</p>
		<form action="view_attendance.php" method="POST">
		<?php
			$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
			$query=mysqli_query($connect,$select);
			while ($res=mysqli_fetch_assoc($query)) {
				if ($res['ClassTeach']=="10th") {?>

					<select name="subject" required="">
						<option disabled="" selected="">Select Subject</option>
						<option value="HTML">HTML</option>
						<option value="CSS">CSS</option>
					</select>
				<?php
				}
				elseif($res['ClassTeach']=="11th"){?>
					<select name="subject" required="">
						<option disabled="" selected="">Select Subject</option>

						<option value="PHP">PHP</option>
						<option value="MYSQL">MY-SQL</option>
					</select>
					<?php

				}
				else{
					?>
					<select  name="subject" required="">
						<option disabled="" selected="">Select Subject</option>

						<option value="SoftwareEngineering">Software Engineering</option>
						<option value="JAVA">JAVA</option>
					</select>
					<?php

				}
			}
				?>
		<input type="submit" name="submit" value="Submit">

		</form><br><br>
		<center><th><a href="t-dashboard.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px;">Back To Dashboard</a></th></center><br>
		</center>
		
	</div><br><br>

	<?php
	if (isset($_POST['submit'])) {
		
		$subject=$_POST['subject'];
		?>
					<center>
						<table width="90%" >
							<tr>
								<th colspan="7"  >
									Attendance Details
								</th>
							</tr>
							<tr>
								<th>
									Date Of Attendance:(YYYY-MM-DD)
								</th>
								<th>
									Students Presents:
								</th>
								<th>
									Students Absent:
								</th>
								<th>
									Students on Leave:
								</th>
								<th>
									Total Students Presents:
								</th>
								<th>
									Total Students Absent:
								</th>
								<th>
									Total Students On Leave:
								</th>
							</tr>
						
					<?php
		
			
				
				
				switch ($subject) {
					case 'HTML':
					
						$Select=mysqli_query($connect, "SELECT * from html_10th");
						while($data=mysqli_fetch_assoc($Select)){?>
						
							
								<tr>
								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;

						case 'CSS':
					?>
					
						
					<?php
						$Select=mysqli_query($connect, "SELECT * from  css_10th");
						while($data=mysqli_fetch_assoc($Select)){?>
							
						
							<tr>

								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;
						case 'PHP':
					?>
					
						
					<?php
						$Select=mysqli_query($connect, "SELECT * from  php_11th");
						while($data=mysqli_fetch_assoc($Select)){?>
							
						
							<tr>

								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;
						case 'MYSQL':
					?>
					
						
					<?php
						$Select=mysqli_query($connect, "SELECT * from  mysql_11th");
						while($data=mysqli_fetch_assoc($Select)){?>
							
						
							<tr>

								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;
						case 'JAVA':
					?>
					
						
					<?php
						$Select=mysqli_query($connect, "SELECT * from  java_12th");
						while($data=mysqli_fetch_assoc($Select)){?>
							
						
							<tr>

								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;
						case 'SoftwareEngineering':
					?>
					
						
					<?php
						$Select=mysqli_query($connect, "SELECT * from  	softwareengineering_12th");
						while($data=mysqli_fetch_assoc($Select)){?>
							
						
							<tr>

								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						
						
						</center>
					
						<?php
					}?>
					</table>

					<?php



						break;
					
					default:
						$_SESSION['Sorry!No Attendance Available'];
						break;
				}
			

			
		}
		
	


	?><br><br>
	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
</body>