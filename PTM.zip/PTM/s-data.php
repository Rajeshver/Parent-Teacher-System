<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>S-Data</title>
	<style type="text/css">
	*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans"
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		.dash{
			height: auto;
			width:90%;
			margin: auto;
			border:2px solid black; 
			background-color: #d2d2d2;
			
			
			
		}
		button{
			width: 20%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
			border-radius: 10px;
		}
		select{
			padding: 10px;
			
			width: 30%;
			border-radius: 10px;

			
		}
		table th,td{
			align-content: center;
			align-items: center;
			justify-content: center;
			text-align: center;
			border: none;
			border-bottom: 2px solid black;
			padding: 10px;
		}
		table{
			width: 90%;
			
		}
		a{
			color: black;
		}
		footer{
			margin-top:110px; 
		}
		th{
			background-color: #d2d2d2;
			color: black;
		}
		td:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
			font-weight: bold;
		}
		th:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
			font-weight: bold;
		}

	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Student Database</h2></center><br>
	<div class="dash"><center><br>
		<form action="s-data.php" method="post">
			<select name="class_fetch">
				<option selected="" disabled="">Select Class</option>
				<option name="10th">10th</option>
				<option name="11th">11th</option>
				<option name="12th">12th</option>
			</select><br><br>
			<button type="submit" name="TS_Data">Fetch Records</button>
		</form>
			
			<center><th><a href="s-data2.php"><h3>Fetch Student Wise Data</h3></a></th></center><br>
			<center><th><a href="t-dashboard.php">Back to Teacher Dashboard</a></th></center><br>
			</form></div><br><br><br>
			
			<?php
			if (isset($_POST['TS_Data'])) {
			$class=$_POST['class_fetch'];
			switch ($class) {
				case '10th':
					?>
						<center>
				<table  width="90" >
					<tr><th colspan="8" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><th>Roll No:</th><th>Class:</th><th>Name:</th><th>Gender:</th><th>Father Name</th> <th>Mobile No:</th><th>Date of Birth:</th><th>Address:</th></tr>
					<?php
					$select="SELECT * FROM 10th ORDER BY rollno";
					$query=mysqli_query($connect,$select);
					while ($res=mysqli_fetch_assoc($query)) {?>
						
						<tr>
						<td><?php echo $res['rollno'];?></td>
						<td><?php echo $res['class'];?></td>
						
						<td><?php echo $res['name'];?></td>
						<td><?php echo $res['Gender'];?></td>
						<td><?php echo $res['fathername'];?></td>
						<td><?php echo $res['mobile'];?></td>
						<td><?php echo $res['dob'];?></td>
						<td><?php echo $res['address'];?></td>
						</tr>
						
							<?php
					}
					?>
					</table>
	
			
					
				<?php
				
					
					break;
					case '11th':
					?>
						<center>
				<table  cellpadding="10" width="90" >
					<tr><th colspan="8" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><th>Roll No:</th><th>Class:</th><th>Name:</th><th>Gender:</th><th>Father Name</th> <th>Mobile No:</th><th>Date of Birth:</th><th>Address:</th></tr>
					<?php
					$select="SELECT * FROM 11th ORDER BY rollno";
					$query=mysqli_query($connect,$select);
					while ($res=mysqli_fetch_assoc($query)) {?>
						
						<tr>
						<td><?php echo $res['rollno'];?></td>
						<td><?php echo $res['class'];?></td>
						
						<td><?php echo $res['name'];?></td>
						<td><?php echo $res['Gender'];?></td>
						<td><?php echo $res['fathername'];?></td>
						<td><?php echo $res['mobile'];?></td>
						<td><?php echo $res['dob'];?></td>
						<td><?php echo $res['address'];?></td>
						</tr>
						
							<?php
					}
					?>
					</table>
	
			
					
				<?php
				
						
						break;
						case '12th':
						?>
						<center>
				<table  cellpadding="10" width="90" >
					<tr><th colspan="8" style="background-color: #2d2d2d; color: white;">Student Details</th></tr>
					<tr><th>Roll No:</th><th>Class:</th><th>Name:</th><th>Gender:</th><th>Father Name</th> <th>Mobile No:</th><th>Date of Birth:</th><th>Address:</th></tr>
					<?php
					$select="SELECT * FROM 12th ORDER BY rollno";
					$query=mysqli_query($connect,$select);
					while ($res=mysqli_fetch_assoc($query)) {?>
						
						<tr>
						<td><?php echo $res['rollno'];?></td>
						<td><?php echo $res['class'];?></td>
						
						<td><?php echo $res['name'];?></td>
						<td><?php echo $res['Gender'];?></td>
						<td><?php echo $res['fathername'];?></td>
						<td><?php echo $res['mobile'];?></td>
						<td><?php echo $res['dob'];?></td>
						<td><?php echo $res['address'];?></td>
						</tr>
						
							<?php
					}
					?>
					</table>
	
			
					
				<?php
						
							break;
				
				default:
					?>
					<script type="text/javascript">
						alert('Invalid Input');
					</script>
					<?php
					break;
			}
			
		}
		?>

		<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
</body>
</html>
