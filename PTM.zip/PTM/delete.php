<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		AddStduents
	</title>
	<style>
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:60%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		.dash input[type=text]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=date]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
		}
		.dash input[type=submit]{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			margin-bottom: 10px;
			border:none;
			background-color: #d2d2d2;
			color: #fff;
		}
		.dash button{
			padding: 10px;
			width: 30%;
			margin-top: 7px;
			margin-bottom: 10px;
			border:none;
			background-color: #d2d2d2;
			color: #fff;
		}
		.dash button:hover{
			background-color: black;
			transition: 0.5s ease;	
		}
		.dash select{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			 margin-bottom: 10px;
		}
		.dash label{
			color: #2d2d2d;
			
		}
		.dash input[type=submit]:hover{
			background-color: black;
			transition: 0.5s ease;
		}
	</style>
	<script src="yes.js"></script>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Delete Existing Student Record:</h2></center><br>
	<div class="dash">
		<p>
			You Must Fill all information correctly
		</p><br>
		<p id="error">

		</p>
		<form action="delete.php" method="POST">
			
		
		<h3>Select The Roll No. whose data you want to Delete:</h3>
		<?php

		$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
		$query=mysqli_query($connect,$select);
		$result=mysqli_fetch_assoc($query);
		
		
		
		$select_class="SELECT * from ".$result['ClassTeach']."";
				$fetch=mysqli_query($connect,$select_class);
				?>
		<select name="rollno" required= <?php  while($show=mysqli_fetch_assoc($fetch)):;?>>
			<option value=<?php echo $show['rollno']; ?>>
				<?php echo $show['rollno']; ?>
				</option><?php
				$_SESSION['ClassT']=$result['ClassTeach'];?>

			<?php endwhile; ?>
			
				 	

		</select><br>
		<button type="submit" name="Delete">Submit</button>  <a href="t-dashboard.php">Cancel</a>
		</form>
		<?php
		if (isset($_POST['Delete'])) {
			$rollno=$_POST['rollno'];

			$delete="DELETE from ".$_SESSION['ClassT']." where rollno='$rollno'";
			$run=mysqli_query($connect,$delete);
			if ($run) {
				?>
				<script type="text/javascript">
					alert("One Record Deleted Successfully")
				</script>
				<?php
			}

			else{
				?>
				<script type="text/javascript">
					alert("Something Went Wrong")
				</script>
				<?php
			}
		}
		?>
