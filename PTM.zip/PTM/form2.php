<?php
include("server2.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>form</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "open sans";
		}
		.form{
			height: auto;
			width:50%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
				background-color: #d2d2d2;
			box-shadow: 4px 3px 15px #2d2d2d; 
			
		}
		.form input[type=text]{
			width: 85%;
			padding: 10px;
		}
		.form input[type=password]{
			width: 85%;
			padding: 10px;
		}
		.form input[type=checkbox]{
			padding: 20px;
			margin: 10px;
		}
		.form input[type=submit]{
			width: 50%;
			padding: 10px;
			border: none;
			background-color: black;
			color: #fff;
		}
	</style>
</head>
<body>
	<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center><br>
	<center><h2 style="background-color: black;color: white; padding: 10px; width: 40%;">Teacher Registration Form</h2></center><br>
	<div class="form">
	<form method="POST" action="form2.php">
		Teacher Name:<br><input type="text" name="tname"><br>
		Teacher Mobile:<br><input type="text" name="tmobile"><br>
		Password:<br><input type="password" name="password"><br>
		Classes:<br>
		<p>You Must Select atleast 1 class</p>
		10th<input type="checkbox" name="class[]" value="10th" checked="">
		11th<input type="checkbox" name="class[]" value="11th">
		12th<input type="checkbox" name="class[]" value="12th"><br>
		Subjects:<br>
	Java<input type="checkbox" name="Subjects[]" value="Java">
	PHP<input type="checkbox" name="Subjects[]" value="PHP">
	C#<input type="checkbox" name="Subjects[]" value="C#">
	C++<input type="checkbox" name="Subjects[]" value="C++">
	HTML<input type="checkbox" name="Subjects[]" value="HTML"><br/><br>
	<input type="submit" name="enter" value="Register"> 
	</form></div><br><br>
		<center><h1 style="background-color: black;color: white; padding: 10px;">Parent-Teacher Information System</h1></center>
	

</body>
</html>