<?php
include("server2.php");
include("record.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>RecordAttendance</title>
	
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}
		.wrapper{
			width: 80%;
			margin: 20px auto;
			border:2px solid black;
			padding: 10px;
			background-color: #d2d2d2;
			
		}
		.wrapper table input[type=text]{
			padding: 10px;
			width: 70%;
			margin: 8px 0px;
		}
		.wrapper  input[type=submit]{
			background-color: #2d2d2d;
			border:none;
			color: white;
			padding: 10px;
			font-weight: bold;
			width: 50%;
		}
		.wrapper  input[type=submit]:hover{
			background-color: black ;
			transition: 0.5s ease;
		}
		.wrapper table{
			border:2px solid #2d2d2d;
			color: black;
			padding: 10px;
		}
		.wrapper table td{
			padding: 10px;
		}
		.wrapper table select{
			padding: 10px;
			width:50%;
		}
		.wrapper button{
			background-color: #2d2d2d;
			border:none;
			color: white;
			padding: 8px;
		}
		.wrapper button:hover{
			background-color: black ;
			transition: 0.5s ease;

		}
		.tot table td input[type=text]{
			width: 100%;
		}
		.total table th input[type=text]{
			width: 100%;
		}

	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Record Attendance</h2></center><br>
	<div class="wrapper">
		<table width="100%">
			<tr>
			
		<th><label>Date Of Attendance:(YYYY/MM/DD)</label></th><th>Subject Of Attendance:</th></tr>
			<tr>
				<th>
		<input type="text" name="Date" value=<?php echo $_SESSION['DateOfAttendance'];?> readonly ></th>
		<th><input type="text" name="Subject" value=<?php echo $_SESSION['Subject'];?> readonly ></th></tr>
	
		<?php
		$select_date="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
		$run=mysqli_query($connect,$select_date);
		while ($data=mysqli_fetch_assoc($run)) {
			?>
			<tr><th>Teacher Name:</th><th>Class:</th></tr><tr><th>
				<input type="text" name="TeacherName" value=<?php echo $data['TeacherName']; ?> readonly>
				</th>

				<th><input type="text" name="Class" value=<?php echo $data['ClassTeach']; ?> readonly></th></tr></table><br>
				<?php
				$_SESSION['ClassTeacher']=$data['ClassTeach'];
				?>
				<form action="record_attendance.php" method="POST">
					
					<table width="100%">
						<tr>
						<th>
							Press and Hold Ctrl Key to select multiple students:
						</th>
					</tr>
					
				</table><br>
				<?php

			$select_students="SELECT * from ".$data['ClassTeach']." ORDER BY 'rollno'";
		
			$run2=mysqli_query($connect,$select_students);
			
				?>

				<table width="100%">
					<tr>
						<th>
							Presents:
						</th>
						<th>
							Absents:
						</th>
						<th>
							Leaves:
						</th>
					</tr>

					
					<tr>
						 
							<th>
								<select multiple="multiple" name="present_rolls[]" <?php while ($Students=mysqli_fetch_assoc($run2)):;?>>

								<option value=<?php echo  $Students['rollno']; ?>> <?php echo $Students['rollno']; ?></option>
									<?php endwhile; ?>
									<option value=<?php

									$select="SELECT * from ".$data['ClassTeach']."";
									$query=mysqli_query($connect,$select);
									while ($Rows=mysqli_fetch_array($query)) {
						
									$r1 =$Rows['rollno'] ;
							
									echo $r1,",";
						
										}
									?>>
								All-Present</option>
								<option value="0"> No Presence </option>
								</select>
							</th>
							<th>
								<?php
								$select_students="SELECT * from ".$data['ClassTeach']."";
		
								$run3=mysqli_query($connect,$select_students);
								?>
								<select multiple="multiple" name="absents_rolls[]" <?php

								while ($absent=mysqli_fetch_assoc($run3)):; 
									
								?>
								>
								<option value=<?php echo  $absent['rollno']; ?>><?php echo $absent['rollno']; ?></option>
									
									<?php endwhile; ?>
									<option value="0">No-Absent</option>
									<option value=<?php
									$select="SELECT * from ".$data['ClassTeach']."";
									$query=mysqli_query($connect,$select);
									while ($Rows=mysqli_fetch_array($query)) {
						
									$r1 =$Rows['rollno'] ;
							
									echo $r1,",";
						
										}


									?>>All-Absent</option>
								</select>
							</th>
							<th>
								<?php
								$select_students="SELECT * from ".$data['ClassTeach']."";
		
								$run4=mysqli_query($connect,$select_students);
								?>
								<select multiple="multiple" name="leaves_rolls[]" <?php

								while ($leave=mysqli_fetch_assoc($run4)):; 
									
								?>
								>
								<option value=<?php echo  $leave['rollno']; ?>><?php echo $leave['rollno']; ?></option>
									
									<?php endwhile; ?>
									<option value="0">No-Leave</option>
									<option value=<?php

									$select="SELECT * from ".$data['ClassTeach']."";
									$query=mysqli_query($connect,$select);
									while ($Rows=mysqli_fetch_array($query)) {
						
									$r1 =$Rows['rollno'] ;
							
									echo $r1,",";
						
										}

									?>>All-On-Leavet</option>
								</select>
							</th>


							
						

						
					</tr>
				</table>
			
					
					
			
				<?php
			}

			?>

				
						
							
						
					<br>
			
		<center><input type="submit" name="calculate" value="Calculate Attendance"></center>
			<div class="total">
				<center><h3>Attendance Details</h3></center>
		<table width="100%">

			<tr>
				<td>Students Present:</td>
			</tr>
			<tr>
				<th><input type="text" name="presents" readonly="" value=<?php
				foreach ($presents as $value1) {
				echo $value1;
			}
?>>

				 
				</th>
			</tr>
			<tr>
				<td>
					Students Absent:
				</td>
			</tr>
			<tr>
				<th>
					<input type="text" name="absents" readonly="" value=
					  <?php
					  foreach ($absents as $value2) {
					echo $value2;
			}?>>  
					 
				</th>
			</tr>
			<tr>
				<td>
					Students On Leave:
				</td>
			</tr>
			<tr>
				<th>
					<input type="text" name="onleave" readonly="" value=
					<?php foreach ($Leaves as  $value3){
					echo $value3;
				}
					?>
						
					
					 >
				</th>
			</tr>
		</table>
	
	<div class="tot">
		<table width="100%">
			<tr>
				Totals:
			</tr>
			<tr>
				<th>
					Present:
				</th>
				<th>
					Absent:
				</th>
				<th>
					Leave:
				</th>
			</tr>
			<tr>
				<td>
					<input type="text" name="T_Present" placeholder="Total Present" readonly="" value=<?php
					if (isset($P)) {
						if ($P=="0")
						{
							echo "No Present";
						}

						else{
					
					echo sizeof($P);
				}
				}
				?>>

				</td>
				<td>
					<input type="text" name="T_Absent" placeholder="Total Absent" readonly="" value=<?php
					if (isset($A)) {
						if ($A=="0" ){
							echo "No Absence";
						}
						else{
						echo sizeof($A);
						}	
					}
					?>>
					
					
				</td>
				<td>
					<input type="text" name="T_Leave" placeholder="Total Leaves" readonly="" value=<?php
					if (isset($L)) {
						if ($L=="0") {
							echo "No Leaves";
						}
						else{
						echo sizeof($L);
					}
						
					}?>>
					
					
				</td>
			</tr>
		</table>
		</div>
	</div><br>
		<center>
			<input type="submit" name="submit_attendance" value="Submit Attendance">
			<br>
			<a href="t-dashboard.php">Back To Dashboard</a>
		</center>

		</div>
	</div>
</form>
	<?php
	if (isset($_POST['submit_attendance'])) {
		$DateOfAttendance=$_SESSION['DateOfAttendance'];
		$S_Present=$_POST['presents'];
		$S_Absent=$_POST['absents'];
		$S_Leave=$_POST['onleave'];
		$P_Total=$_POST['T_Present'];
		$A_Total=$_POST['T_Absent'];
		$L_Total=$_POST['T_Leave'];

		switch ($_SESSION['Subject']) {
			case 'HTML':
				$insert="INSERT Into html_10th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);

				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				break;
				case 'CSS':
					$insert="INSERT Into css_10th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);
				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
					break;
			case 'PHP':
					$insert="INSERT Into php_11th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);
				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
					break;
					case 'MYSQL':
					$insert="INSERT Into mysql_11th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);
				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
					break;
					case 'SoftwareEngineering':
					$insert="INSERT Into softwareengineering_12th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);
				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
					break;
					case 'JAVA':
					$insert="INSERT Into java_12th ( DateOfAttendance,Present_RollNo,Absent_RollNo,Leave_Rollno,Total_Presents,Total_Absents,Total_Leaves ) VALUES ('$DateOfAttendance','$S_Present','$S_Absent','$S_Leave','$P_Total','$A_Total','$L_Total')";
				$query_attendance=mysqli_query($connect,$insert);
				if (!$query_attendance) {
					?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				}
				else{
					?>
					<script type="text/javascript">
						alert("Attendance Successful!")
						window.location="attendance_info.php";
					</script>
					<?php
				}
					break;
			default:
			?>
					<script type="text/javascript">
						alert("Sorry!Something went wrong");
					</script>
					<?php
				
			
				break;
		}
		
	}





	?>
		
</body>
</html>