<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Child Data</title>
	<style>
	*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		table th,td{
			align-content: center;
			align-items: center;
			justify-content: center;
			text-align: center;
			border: none;
			border-bottom: 2px solid black;
			padding: 15px;
		}
		table{
			margin-bottom: 60px;
		}
		a{
			color: black;
		}
		td:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}
		th:hover{
			background-color: #d2d2d2;
			transition: 0.5s ease;
			cursor: pointer;
		}

	</style>
	
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Students All Personal Data</h2></center><br>
	<?php
				$select1="SELECT * from parent where mobile=".$_SESSION['mobile']."";
				$select=mysqli_query($connect,$select1);
				while($data=mysqli_fetch_assoc($select)){?>
				

				<?php

				$statement2=mysqli_query($connect,"SELECT * from ".$data['sclass']." where rollno=".$data['srollno']."");
				$result=mysqli_fetch_assoc($statement2);
				?>
				<center>
				<table width="60%" align="center">
					<tr>
						<th colspan="2" style="background-color: #2d2d2d; color: white">
							All Details
						</th>
					</tr>
					<tr>
						<td>
							 Name:
						</td>
						<th>
							<?php echo $result['name']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Class:
						</td>
						<th>
							<?php echo $result['class']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Roll Number:
						</td>
						<th>
							<?php echo $result['rollno']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Gender:
						</td>
						<th>
							<?php echo $result['Gender']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Father Name:
						</td>
						<th>
							<?php echo $result['fathername']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Mobile Number:
						</td>
						<th>
							<?php echo $result['mobile']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Date Of Birth:
						</td>
						<th>
							<?php echo $result['dob']; ?>
						</th>
					</tr>
					<tr>
						<td>
							 Address:
						</td>
						<th>
							<?php echo $result['address']; ?>
						</th>
					</tr>
					<tr>
						<th colspan="2">
							<a href="p-dashboard.php" style="color: black">Back To Dashboard</a>
						</th>
					</tr>
					
				</table></center>
				<?php
			}
			

			?><br><br><br>

			<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

</body>
</html>
<?php?>