<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>AddRemove</title>
	<style type="text/css">
				*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		.dash a{
			text-decoration: none;
			color: white;
		}
		.dash select{
			width: 90%;
			padding: 8px;
		}
		.dash select option{
			padding: 10px;


		}
		.dash input[type=submit]{
			border:none;
			background-color: black;
			color: white;
			padding: 8px;
			width: 50%;
		}
		footer{
			margin-top: 300px;
		}

	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Add / Delete or Update Student's Data:</h2></center><br>
	<div class="dash">
		<form action="addremove.php" method="POST">
			<select name="option">
				<option disabled="" selected="">
					Select Any Option
					
				</option>
				<option value="ADD">
					Add New Student Data
				</option>
				<option value="REMOVE">
					Remove Exixting Student Data
				</option>
				<option value="UPDATE">
					Updata Existing Student Data
				</option>
			</select><br><br>
			<input type="submit" name="choice" value="Submit">
		</form><br><center>
		<a href="t-dashboard.php" style="color: black;">Back to Dashboard</a>
	</center>
	</div>
	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>
</body>
</html>
<?php
	if (isset($_POST['choice'])) {
		if (isset($_POST['option'])) {
			
		
		$option=$_POST['option'];
		if ($option=="ADD") {
			header("location:add.php");
		}
		else if ($option=="REMOVE") {
			header("location:delete.php");
		}
		else{
			header("location:update.php");
		}
	}
		else{
			?>
			<script type="text/javascript">
				alert("Please Select A Valid Option");
			</script>
			<?php

		}
	}
?>