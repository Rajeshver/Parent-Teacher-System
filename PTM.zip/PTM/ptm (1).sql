-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 30, 2020 at 10:13 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ptm`
--

-- --------------------------------------------------------

--
-- Table structure for table `10th`
--

DROP TABLE IF EXISTS `10th`;
CREATE TABLE IF NOT EXISTS `10th` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `class` varchar(20) NOT NULL DEFAULT '10th',
  `rollno` mediumint(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`,`rollno`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `10th`
--

INSERT INTO `10th` (`id`, `name`, `class`, `rollno`, `Gender`, `fathername`, `mobile`, `dob`, `address`) VALUES
(1, 'Rajeshver', '10th', 101, 'Male', 'Suresh', 8989898989, '2020-04-14', 'abc city, abc state,'),
(2, 'Rahul', '10th', 102, 'Male', 'Rakesh ', 7878787878, '2020-04-10', 'abc city, abc state,'),
(3, 'Rakesh', '10th', 103, 'Male', 'Ramesh', 8989898998, '2020-04-10', 'abc city, abc state,'),
(4, 'Rajbeer Singh', '10th', 104, 'Male', 'Rajdeep Singh', 7878787878, '2020-04-24', '  '),
(5, 'Simran Ji', '10th', 105, 'Female', 'Rajinder singh Ji', 8989898989, '2020-04-03', 'abc city, abc state1');

-- --------------------------------------------------------

--
-- Table structure for table `11th`
--

DROP TABLE IF EXISTS `11th`;
CREATE TABLE IF NOT EXISTS `11th` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `class` varchar(20) NOT NULL DEFAULT '10th',
  `rollno` mediumint(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`,`rollno`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11th`
--

INSERT INTO `11th` (`id`, `name`, `class`, `rollno`, `Gender`, `fathername`, `mobile`, `dob`, `address`) VALUES
(5, 'Simran', '11th', 203, 'Female', 'Rajinder singh', 7878787878, '2020-04-03', 'abc city, abc state,11230'),
(2, 'Mandeep', '11th', 202, 'Female', 'Rajdeep', 8989898988, '2020-04-11', 'abc'),
(4, 'Rajbeer Singh', '11th', 201, 'Male', 'Rajdeep Singh', 7878787878, '2020-04-01', 'abc city, abc state,11230'),
(6, 'Ajay', '11th', 204, 'Male', 'Ajay Ji', 8989898998, '2020-04-04', 'abc city, abc state,11230');

-- --------------------------------------------------------

--
-- Table structure for table `12th`
--

DROP TABLE IF EXISTS `12th`;
CREATE TABLE IF NOT EXISTS `12th` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `class` varchar(20) NOT NULL DEFAULT '10th',
  `rollno` mediumint(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`,`rollno`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `12th`
--

INSERT INTO `12th` (`id`, `name`, `class`, `rollno`, `Gender`, `fathername`, `mobile`, `dob`, `address`) VALUES
(1, 'Rajat', '12th', 301, 'Male', 'Suresh', 8989898989, '2020-04-10', 'abc city, abc state,'),
(3, 'Rajbeer Singh', '12th', 302, 'Male', 'Suresh', 8989898997, '2020-04-02', 'abc city, abc state,11230'),
(4, 'Mandeep', '12th', 303, 'Male', 'Rajdeep Singh', 7878787878, '2020-04-24', 'abc city, abc state,'),
(5, 'Daljeet', '12th', 304, 'Female', 'Rajdeep', 8989898989, '2020-04-04', 'abc'),
(6, 'Damini', '12th', 305, 'Female', 'Rahul', 7878787878, '2020-04-03', 'abc city, abc state1');

-- --------------------------------------------------------

--
-- Table structure for table `css_10th`
--

DROP TABLE IF EXISTS `css_10th`;
CREATE TABLE IF NOT EXISTS `css_10th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `css_10th`
--

INSERT INTO `css_10th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '101,103,104', '102', '105', 3, 1, 1),
(2, '2020-04-29', '101,104', '102,103', '102', 2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `html_10th`
--

DROP TABLE IF EXISTS `html_10th`;
CREATE TABLE IF NOT EXISTS `html_10th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `html_10th`
--

INSERT INTO `html_10th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '101,102,103', '104', '105', 3, 1, 1),
(2, '2020-04-29', '101,103', '104', '102,105', 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `java_12th`
--

DROP TABLE IF EXISTS `java_12th`;
CREATE TABLE IF NOT EXISTS `java_12th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `java_12th`
--

INSERT INTO `java_12th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '301,302', '304', '302,305', 2, 1, 2),
(2, '2020-04-29', '301,302,303', '304', '305', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mysql_11th`
--

DROP TABLE IF EXISTS `mysql_11th`;
CREATE TABLE IF NOT EXISTS `mysql_11th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mysql_11th`
--

INSERT INTO `mysql_11th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '203,202', '201', '204', 2, 1, 1),
(2, '2020-04-29', '203', '202,201', '204', 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

DROP TABLE IF EXISTS `parent`;
CREATE TABLE IF NOT EXISTS `parent` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `relation` varchar(20) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `sclass` varchar(20) NOT NULL,
  `srollno` bigint(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`id`, `name`, `password`, `mobile`, `relation`, `sname`, `sclass`, `srollno`) VALUES
(1, 'Rajinder Singh', 'rajinder1', 8989898989, 'Father', 'Simran Ji', '10th', 105),
(2, 'Suresh', 'Suresh1', 8360521010, 'Father', 'Rajeshver', '10th', 101),
(3, 'Rajinder Singh', 'rajbeer1', 8989898997, 'Father', 'Rajbeer Singh', '11th', 201),
(4, 'Rajat Singh', 'rajat10', 8989898998, 'Father', 'Rajat', '12th', 301),
(5, 'Rajdeep Singh', 'rajdeep1', 8989898980, 'Father', 'Daljeet', '12th', 304);

-- --------------------------------------------------------

--
-- Table structure for table `php_11th`
--

DROP TABLE IF EXISTS `php_11th`;
CREATE TABLE IF NOT EXISTS `php_11th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `php_11th`
--

INSERT INTO `php_11th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '203,202', '201', '204', 2, 1, 1),
(2, '2020-04-29', '203,201', '202', '204', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `softwareengineering_12th`
--

DROP TABLE IF EXISTS `softwareengineering_12th`;
CREATE TABLE IF NOT EXISTS `softwareengineering_12th` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `DateOfAttendance` date NOT NULL,
  `Present_RollNo` varchar(300) NOT NULL,
  `Absent_RollNo` varchar(300) NOT NULL,
  `Leave_Rollno` varchar(300) NOT NULL,
  `Total_Presents` bigint(10) NOT NULL,
  `Total_Absents` bigint(10) NOT NULL,
  `Total_Leaves` bigint(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `softwareengineering_12th`
--

INSERT INTO `softwareengineering_12th` (`ID`, `DateOfAttendance`, `Present_RollNo`, `Absent_RollNo`, `Leave_Rollno`, `Total_Presents`, `Total_Absents`, `Total_Leaves`) VALUES
(1, '2020-04-28', '301,302,303', '304', '305', 3, 1, 1),
(2, '2020-04-29', '301,303,304', '302', '305', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `teacherdata`
--

DROP TABLE IF EXISTS `teacherdata`;
CREATE TABLE IF NOT EXISTS `teacherdata` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `TeacherName` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Mobile` bigint(15) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Qualification` varchar(20) NOT NULL,
  `ClassTeach` varchar(50) NOT NULL,
  `Joining` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacherdata`
--

INSERT INTO `teacherdata` (`ID`, `TeacherName`, `Gender`, `Password`, `Mobile`, `Address`, `Qualification`, `ClassTeach`, `Joining`) VALUES
(1, 'Ashwani', 'Male', 'ashwani1', 8360521507, 'abcabcbacxsasas jalandhar city', 'B.TECH', '10th', '2020-04-01'),
(2, 'Naresh', 'Male', 'naresh1', 8360521508, 'abcabcbacxsasas jalandhar city', 'MBA', '11th', '2020-04-11'),
(3, 'Narinder', 'Male', 'narinder', 8360521509, 'abcabcbacxsasas jalandhar city', 'B.TECH', '12th', '2020-04-01');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
