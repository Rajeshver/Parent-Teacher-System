<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendance Info</title>
	<style type="text/css">
				*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		a{
			text-decoration: none;
			color: white;
		}
		input[type=date]{
			padding: 10px;
			width: 95%;
			margin: 8px 0px;
		}
		select{
			padding: 10px;
			width: 95%;
			margin: 8px 0px;
		}
		input[type=submit]{
			width: 100%;
			padding: 10px;
			border: none;
			background-color: black;
			color: #fff;
		}
		input[type=submit]:hover{
			font-weight: bold;
			transition: 0.6s ease;
		}
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Select Data To Take Attendance</h2></center><br>
	<div class="dash">
		<form action="attendance_info.php" method="POST">
		<label>Select Date:
		</label><br>
		
			<input type="date" name="date_attendace" required=""><br>
		
		<label>Select Subject:</label><br>
		
			
			<?php
			$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
			$query=mysqli_query($connect,$select);
			while ($res=mysqli_fetch_assoc($query))
			 {
				if ($res['ClassTeach']=="10th") {?>
					<select name="subject" required="">
						<option value="HTML">HTML</option>
						<option value="CSS">CSS</option>
					</select>
				<?php
				}
				elseif($res['ClassTeach']=="11th"){?>
					<select name="subject" required="">
						<option value="PHP">PHP</option>
						<option value="MYSQL">MY-SQL</option>
					</select>
					<?php

				}
				else{?>
					<select  name="subject" required="">
						<option value="SoftwareEngineering">Software Engineering</option>
						<option value="JAVA">JAVA</option>
					</select>
					<?php
				}

				}
			
			?>

			
		<br>
		<input type="submit" name="takeattendance" value="Take Attendance"><br><br>
		</form>
		<center><th><a href="t-dashboard.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px;">Back To Dashboard</a></th></center><br>
		</center>
	</div>

	<?php

	if(isset($_POST['takeattendance'])){

		$date=$_POST['date_attendace'];
		$subject=$_POST['subject'];
		

		switch ($subject) {

			case 'HTML':
				$Select="SELECT * from html_10th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_fetch_assoc($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;

				case 'CSS':
				$Select="SELECT * from css_10th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_num_rows($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;

				case 'PHP':
				$Select="SELECT * from php_11th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_num_rows($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;

				case 'MYSQL':
				$Select="SELECT * from mysql_11th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_num_rows($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;

				case 'SoftwareEngineering':
				$Select="SELECT * from softwareengineering_12th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_num_rows($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;

				case 'JAVA':
				$Select="SELECT * from java_12th where DateOfAttendance='$date'";
				$query=mysqli_query($connect,$Select);
				if (mysqli_num_rows($query)>0) {
					?>
					<script type="text/javascript">
						alert("Attendance already made for the given date")
						window.location="attendance_info.php";
					</script>
					<?php
				}
				else{
					$_SESSION['DateOfAttendance']=$date;
					$_SESSION['Subject']=$subject;
					header("location:record_attendance.php");
				}
				break;
			
			default:
				
				break;
		}
	}

		
	?>


</body>
</html>


<?php?>