<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>T-dashboard</title>
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 10px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 10px;
			width: 45%;
		}
		.dash{
			height: auto;
			width:60%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			background-color: #d2d2d2;
			border-radius: 10px;
			
		}
		button{
			width: 50%;
			border: none;
			background-color: black;
			color: white;
			padding: 20px;
		}
		a{
			text-decoration: none;
			color: white;
		}
		
	</style>
</head>
<body>
	

	
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>Teacher Dashboard</h2></center><br>
	<?php
	if (isset($_SESSION['msg'])) {
		echo "<center><h3>",$_SESSION['msg'],"</h3></center>";
		unset($_SESSION['msg']);
	}
	?>
	<?php
	
			
			$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
			$query=mysqli_query($connect,$select);
			while ($res=mysqli_fetch_assoc($query)) {
				echo "<h3><center>Welcome ",$res['TeacherName']," Sir</h3></center>";	
			}

			?>
	<div class="dash"><center>
		<button ><a href="s-data.php"> <h3 >Student Data</h3></a></button><br><br>

		<button><a href="attendance.php"> <h3>Student Attendance</h3></a></button><br><br>
		<button><a href="addremove.php"><h3>Add / Remove Students</h3></a></button><br><br>
		<button><a href="t_account.php"><h3>My Data</h3></a></button><br><br></center><br>
		
			
				<center><th><a href="logout.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px; ">Log Out</a></th></center><br>
				

			

		
	</div><br><br><br><br>
	<footer><center><h1>Parent-Teacher Information System</h1></center></footer>

</body>
</html>