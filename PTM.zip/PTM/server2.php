<?php

session_start();
$host='localhost';
		$username='root';
		$password1='';
		$database='ptm';

	$connect=mysqli_connect($host,$username,$password1,$database);
	if (!$connect) {
	echo "cannot connect";
}
else
{
	//echo "connected";
}
if (isset($_POST['fetch'])) 
	{
		$sname=$_POST['name'];
		$rollno=$_POST['rollno'];
		
		$name=$_POST['uname'];
		$password=$_POST['password'];
		$mobile=$_POST['mobile'];
		$relation=$_POST['Relation'];
		$class= $_POST['class'];

		switch ($class) {
		case '10th':

			$user_check="SELECT * FROM parent WHERE mobile='$mobile' OR srollno='$rollno' LIMIT 1";
			$exist=mysqli_query($connect,$user_check);
			$users=	mysqli_fetch_assoc($exist);
			if ($users) {
			if ($users['mobile']==$mobile OR $users['srollno']==$rollno) {
			?>
			<script type="text/javascript">
				alert("Account already exist\n\n You Must Log in or try different details");
				window.location="dashboard.php";
			</script>
			<?php
				


	}
}
			else{
				
			$select="SELECT * from 10th where name='$sname' AND rollno='$rollno'";
			$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {
				if (empty($name)) {
				?>
				<script type="text/javascript">
			
				alert("Name Cannot be empty");
				window.location="registration.php";
			</script>
			<?php
			}
			elseif (ctype_digit($name) ){
			?>
			<script type="text/javascript">
				alert("Name cannot contain numbers");
				window.location="registration.php";

			
			</script>
			<?php
			}
				elseif (empty($password)) {
				?>
				<script type="text/javascript">
			
				alert("Password Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_alnum($password)) {
				?>
				<script type="text/javascript">
						alert("Password must contain digits and characters both");
						window.location="registration.php";
					
				</script>
				<?php
				}	
				elseif (strlen($password)<6) {?>
				<script type="text/javascript">
					alert("Enter the password of atleast 6 characters ");
					window.location="registration.php";
					
				</script>
				<?php
			}


				elseif (empty($mobile)) {
				?>
				<script type="text/javascript">
			
				alert("Mobile Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_digit($mobile)) {
			?>
				<script type="text/javascript">
				alert("Mobile Number Can only contain digits");
				window.location="registration.php";
				
				</script>
				<?php
				}
				elseif (strlen($mobile)!=10) {
				?>
				<script type="text/javascript">
					alert("Mobile number must contain only digits ");
				window.location="registration.php";
					
				</script>
				<?php
			}
			elseif (empty($sname)) {
				?>
				<script type="text/javascript">
			
				alert("Please Enter your Student Name");
				window.location="registration.php";
				</script>
				<?php
				}
				
				
				else{



			$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
				$query2=mysqli_query($connect,$insert);
				$_SESSION['mobile']=$mobile;
				$_SESSION['msg']="You are Successfully Logged In";
				header('location:p-dashboard');

			}
		}
			else{?>
				<script type="text/javascript">
				alert("No record found.Please enter correct information");
				header('location:registration.php');
			</script>
			<?php
			}
			}
	
			break;
				
				case '11th':
				$user_check="SELECT * FROM parent WHERE mobile='$mobile' OR srollno='$rollno' LIMIT 1";
			$exist=mysqli_query($connect,$user_check);
			$users=	mysqli_fetch_assoc($exist);
			if ($users) {
			if ($users['mobile']==$mobile OR $users['srollno']==$rollno) {
			?>
			<script type="text/javascript">
				alert("Account already exist\n\n You Must Log in or try different details");
				window.location="dashboard.php";
			</script>
			<?php
				


	}
}
			else{
				
			$select="SELECT * from 11th where name='$sname' AND rollno='$rollno'";
			$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {
				if (empty($name)) {
				?>
				<script type="text/javascript">
			
				alert("Name Cannot be empty");
				window.location="registration.php";
			</script>
			<?php
			}
			elseif (ctype_digit($name) ){
			?>
			<script type="text/javascript">
				alert("Name cannot contain numbers");
				window.location="registration.php";

			
			</script>
			<?php
			}
				elseif (empty($password)) {
				?>
				<script type="text/javascript">
			
				alert("Password Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_alnum($password)) {
				?>
				<script type="text/javascript">
						alert("Password must contain digits and characters both");
						window.location="registration.php";
					
				</script>
				<?php
				}	
				elseif (strlen($password)<6) {?>
				<script type="text/javascript">
					alert("Enter the password of atleast 6 characters ");
					window.location="registration.php";
					
				</script>
				<?php
			}


				elseif (empty($mobile)) {
				?>
				<script type="text/javascript">
			
				alert("Mobile Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_digit($mobile)) {
			?>
				<script type="text/javascript">
				alert("Mobile Number Can only contain digits");
				window.location="registration.php";
				
				</script>
				<?php
				}
				elseif (strlen($mobile)!=10) {
				?>
				<script type="text/javascript">
					alert("Mobile number must contain only digits ");
				window.location="registration.php";
					
				</script>
				<?php
			}
			elseif (empty($sname)) {
				?>
				<script type="text/javascript">
			
				alert("Please Enter your Student Name");
				window.location="registration.php";
				</script>
				<?php
				}
				
				
				else{
				$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
				$query2=mysqli_query($connect,$insert);
				$_SESSION['mobile']=$mobile;
				$_SESSION['msg']="You are Successfully Logged In";
				header('location:p-dashboard');

			}
		}
			else{?>
				<script type="text/javascript">
				alert("No record found.Please enter correct information");
				header('location:registration.php');
			</script>
			<?php
			}
			}
					
					break;
					case '12th':
						$user_check="SELECT * FROM parent WHERE mobile='$mobile' OR srollno='$rollno' LIMIT 1";
			$exist=mysqli_query($connect,$user_check);
			$users=	mysqli_fetch_assoc($exist);
			if ($users) {
			if ($users['mobile']==$mobile OR $users['srollno']==$rollno) {
			?>
			<script type="text/javascript">
				alert("Account already exist\n\n You Must Log in or try different details");
				window.location="dashboard.php";
			</script>
			<?php
				


	}
}
			else{

				
			$select="SELECT * from 12th where name='$sname' AND rollno='$rollno'";
			$query=mysqli_query($connect,$select);
			if ($res=mysqli_fetch_row($query)>0) {
				if (empty($name)) {
				?>
				<script type="text/javascript">
			
				alert("Name Cannot be empty");
				window.location="registration.php";
			</script>
			<?php
			}
			elseif (ctype_digit($name) ){
			?>
			<script type="text/javascript">
				alert("Name cannot contain numbers");
				window.location="registration.php";

			
			</script>
			<?php
			}
				elseif (empty($password)) {
				?>
				<script type="text/javascript">
			
				alert("Password Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_alnum($password)) {
				?>
				<script type="text/javascript">
						alert("Password must contain digits and characters both");
						window.location="registration.php";
					
				</script>
				<?php
				}	
				elseif (strlen($password)<6) {?>
				<script type="text/javascript">
					alert("Enter the password of atleast 6 characters ");
					window.location="registration.php";
					
				</script>
				<?php
			}


				elseif (empty($mobile)) {
				?>
				<script type="text/javascript">
			
				alert("Mobile Cannot be empty");
				window.location="registration.php";
				</script>
				<?php
				}
				elseif (!ctype_digit($mobile)) {
			?>
				<script type="text/javascript">
				alert("Mobile Number Can only contain digits");
				window.location="registration.php";
				
				</script>
				<?php
				}
				elseif (strlen($mobile)!=10) {
				?>
				<script type="text/javascript">
					alert("Mobile number must contain only digits ");
				window.location="registration.php";
					
				</script>
				<?php
			}
			elseif (empty($sname)) {
				?>
				<script type="text/javascript">
			
				alert("Please Enter your Student Name");
				window.location="registration.php";
				</script>
				<?php
				}
				
				
				else{
				$insert="INSERT into parent(name,password,mobile,relation,sname,sclass,srollno) VALUES ('$name','$password','$mobile','$relation','$sname','$class','$rollno')";
				$query2=mysqli_query($connect,$insert);
				$_SESSION['mobile']=$mobile;
				$_SESSION['msg']="You are Successfully Logged In";
				header('location:p-dashboard');

			}
		}
			else{?>
				<script type="text/javascript">
				alert("No record found.Please enter correct information");
				header('location:registration.php');
			</script>
			<?php
			}
			}	
			break;





		default:
			?>
			<script type="text/javascript">
				alert("OOPs!Something Went Wrong Please Try Again");
				window.location="registration.php";
			</script>
			<?php
			break;
	}
}
			

		if (isset($_POST['RegisterTeacher'])) {
		
		$name=$_POST['teacher_name'];
		$mobile=$_POST['Mobile'];
		$pass=$_POST['Password'];
		$date_join=$_POST['joining'];
		$address=$_POST['Address'];
		$qualification=$_POST['qualification'];
		$class=$_POST['class'];
		$gender=$_POST['gender'];
		$user_check="SELECT * FROM teacherdata WHERE Mobile='$mobile' LIMIT 1";
		$exist=mysqli_query($connect,$user_check);
		$users=	mysqli_fetch_assoc($exist);
		if ($users) {
		if ($users['Mobile']==$mobile) {
		
		?>
		<script type="text/javascript">
			alert("Mobile Number Already Exixt");
			window.location="dashboard.php";
		</script>
		<?php


			}
		}		
		
			elseif(!isset($class))	{
				?>
				<script type="text/javascript">
					alert("You Must Select Class To Teach");
					window.location="teacher_registration.php";
				</script>
				<?php
			}
			elseif(!isset($qualification))	{
				?>
				<script type="text/javascript">
					alert("You Must Select Your Qualification");
					window.location="teacher_registration.php";
				</script>
				<?php
			}

		
			elseif (!ctype_alnum($pass)) {
				?>
				<script type="text/javascript">
						alert("Password must contain digits and characters both");
						window.location="form2.php";
					
				</script>
				<?php
				}	
				
		

		else{

		$insert="INSERT INTO teacherdata(TeacherName,Gender,Password,Mobile,Address,Qualification,ClassTeach,Joining) VALUES('$name','$gender','$pass','$mobile','$address','$qualification','$class','$date_join')";
		$query=mysqli_query($connect,$insert);
		if (!$query) {
			?>
			<script type="text/javascript">
				alert("Cannot perform action");
			</script>
			<?php
		}
		else {
			?>
			<script type="text/javascript">
				alert("Congrats your Account built");
			</script>
			<?php
	
		$_SESSION['mobile']=$mobile;
		$_SESSION['password']=$pass;
		
		$_SESSION['msg']="You are Successfully Logged In";
		header("location:t-dashboard.php");
	}
	}
}
		

		if (isset($_POST['teacher_login'])) {

			
			$mobile=$_POST['t_mobile'];
			$password=$_POST['tPassword'];
			$check="SELECT * FROM teacherdata WHERE Mobile='$mobile' AND Password='$password'";
			$result=mysqli_query($connect,$check);
			if (mysqli_num_rows($result)==1) {
				$_SESSION['mobile']=$mobile;
				
				$_SESSION['password']=$password;
				header('location:t-dashboard.php');
				$_SESSION['msg']="You are logged in";
				
				}
				else{
					$_SESSION['msg']="Wrong mobile number and password combination";
					
				}
			
		}
		if (isset($_POST['parent_login'])) {

			
			$mobile=$_POST['p_mobile'];
			$password=$_POST['ppassword'];
			$check="SELECT * FROM parent WHERE mobile='$mobile' AND password='$password'";
			$result=mysqli_query($connect,$check);
			if (mysqli_num_rows($result)==1) {
				$_SESSION['mobile']=$mobile;
				
				$_SESSION['password']=$password;
				header('location:p-dashboard.php');
				$_SESSION['msg']="You are logged in";
				
				}
				else{
					$_SESSION['msg']="Wrong mobile number and password combination";
					
				}
			
		}
		


?>