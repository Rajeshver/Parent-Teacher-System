<?php
	include("server2.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Count Rows
	</title>
</head>
<body>
	<form action="countrows.php" method="POST">
	<select name="Class">
		<option value="10th">
			10th
		</option>
		<option value="11th">
			11th
		</option>
		<option value="12th">
			12th
		</option>
	</select><br>
	<input type="submit" name="submit" value="Count">
</form>

</body>
</html>

<?php

	if (isset($_POST['submit'])) {
		if (isset($_POST['Class'])) {
			$class=$_POST['Class'];
			switch ($class) {
				case '10th':
					$select="SELECT * from 10th";
					$query=mysqli_query($connect,$select);
					while ($Rows=mysqli_fetch_array($query)) {
						
						$r1 =$Rows['rollno'] ;
						
						echo $r1,",";
						
						}
						
					
					
						
					
					break;
				case '11th':
					$select="SELECT * from 11th";
					$query=mysqli_query($connect,$select);
					$Rows=mysqli_num_rows($query);
					if (!$query) {
						?>
						<script type="text/javascript">
							document.write("Query cannot be performed");
						</script>
						<?php
					}
					else{
						echo $Rows;
					}
					break;
					case '12th':
						
						
					$select="SELECT * from 12th";
					$query=mysqli_query($connect,$select);
					$Rows=mysqli_num_rows($query);
					if (!$query) {
						?>
						<script type="text/javascript">
							document.write("Query cannot be performed");
						</script>
						<?php
					}
					else{
						echo $Rows;
					}
					break;
				default:
					# code...
					break;
			}
		}
	}

?>