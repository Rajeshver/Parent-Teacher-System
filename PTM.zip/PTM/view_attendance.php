<?php
include("server2.php");

if (!isset($_SESSION['mobile'])) {
	header("location:dashboard.php");
	$_SESSION['msg']="You must log in first";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>View-Attendance</title>
	<style type="text/css">
				*{
			padding: 0;
			margin: 0;
			font-family: "Open Sans";
		}
		h1{
			color: white;
			background-color: black;
			padding: 8px 5px;
		}
		h2{
			color: white;
			background-color: black;
			padding: 8px 5px;
			width: 45%;
		}

		.dash{
			height: auto;
			width:40%;
			margin: auto;
			border:2px solid black; 
			
			padding: 20px;
			
		}
		h3{
			padding: 5px 8px;
		}
		input[type=submit]{
			width:90%;
			border: none;
			background-color: #d2d2d2;
			color: white;
			padding: 10px;
		}
		input[type=submit]:hover{
			background-color: black;
			color: white;
			transition: 0.5s ease;
		}
		a{
			text-decoration: none;
			color: white;
		}
		.dash select{
			padding: 10px;
			width: 90%;
			margin-top: 7px;
			 margin-bottom: 10px;
		}
	</style>
</head>
<body>
	<center><h1>Parent-Teacher Information System</h1></center><br>
	<center><h2>View Attendance</h2></center><br>
	<div class="dash">
		<form action="view_attedance.php" method="POST">
			
		
		
		<p>Select Subject:</p>
		<?php
			$select="SELECT * from teacherdata where mobile=".$_SESSION['mobile']."";
			$query=mysqli_query($connect,$select);
			while ($res=mysqli_fetch_assoc($query)) {
				if ($res['ClassTeach']=="10th") {?>
					<select name="subject" required="">
						<option value="HTML">HTML</option>
						<option value="CSS">CSS</option>
					</select>
				<?php
				}
				elseif($res['ClassTeach']=="11th"){?>
					<select name="subject" required="">
						<option value="PHP">PHP</option>
						<option value="MYSQL">MY-SQL</option>
					</select>
					<?php

				}
				else{
					?>
					<select  name="subject" required="">
						<option value="SoftwareEngineering">Software Engineering</option>
						<option value="JAVA">JAVA</option>
					</select>
					<?php

				}
			}
				?>
		<input type="submit" name="submit" value="Submit">

		</form><br><br>
		<center><th><a href="t-dashboard.php" style="color: black; font-weight: bold; border: 1.5px solid black;padding:10px;">Back To Dashboard</a></th></center><br>
		</center>
		
	</div>
	<?php
	if (isset($_POST['submit'])) {
		
			if (isset($_POST['subject'])) {
				
				$subject=$_POST['subject'];
				switch ($subject) {
					case 'HTML':
						$Select=mysqli_query($connect, "SELECT * from html_10th");
						$data=mysqli_fetch_assoc($Select);?>
						<center>
						<table width="80%">
							<tr>
								<th colspan="7" >
									Attendance Details
								</th>
							</tr>
							<tr>
								<th>
									Date Of Attendance:
								</th>
								<th>
									Students Presents:
								</th>
								<th>
									Students Absent:
								</th>
								<th>
									Students on Leave:
								</th>
								<th>
									Total Students Presents:
								</th>
								<th>
									Total Students Absent:
								</th>
								<th>
									Total Students On Leave:
								</th>
							</tr>
							<tr>
								<td>
									<?php echo $data['DateOfAttendance']; ?>
								</td>
								<td>
									<?php echo $data['Present_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Absent_RollNo']; ?>
								</td>
								<td>
									<?php echo $data['Leave_Rollno']; ?>
								</td>
								<td>
									<?php echo $data['Total_Presents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Absents']; ?>
								</td>
								<td>
									<?php echo $data['Total_Leaves']; ?>
								</td>
							</tr>

						</table>
						</center>
						<?php


						break;
					
					default:
						# code...
						break;
				}
			}
			else{
				$_SESSION['msg']="You Must Select Select Subject first";
			}
		}
		
	


	?>